package com.ironlady.aiassistant.dto;

public class RecommendationResponse {
	 private Long leadId;
	    private String plan;
	    
	    
		public Long getLeadId() {
			return leadId;
		}
		public void setLeadId(Long leadId) {
			this.leadId = leadId;
		}
		public String getPlan() {
			return plan;
		}
		public void setPlan(String plan) {
			this.plan = plan;
		}
	    
	    
}
