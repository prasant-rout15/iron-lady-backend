package com.ironlady.aiassistant;

public class ProgramData {
	 public static final String DATA = """
			    Iron Lady Programs:

			    1. Leadership Masterclass:
			    For beginners needing clarity in leadership journey.
			    Keywords: basics, clarity, confidence.

			    2. Leadership Essentials:
			    For working women facing confidence, office politics, visibility issues.
			    Keywords: confidence, politics, visibility, leadership.

			    3. 100 Board Members Program:
			    For mid/senior professionals wanting executive presence and board roles.
			    Keywords: board, strategy, executive presence.

			    4. Master of Business Warfare:
			    For women entrepreneurs struggling with business growth and competition.
			    Keywords: business, growth, competition, strategy.
			    """;
}
